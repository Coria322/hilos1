/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Hilos;

import gui.v1;


public class Proceso1 extends Thread{
    
    @Override
    public void run(){
       v1 ventana1 = new v1();
    }
}
