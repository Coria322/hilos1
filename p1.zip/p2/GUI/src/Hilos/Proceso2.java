/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Hilos;

import gui.v2;
/**
 *
 * @author sonic
 */
public class Proceso2 implements Runnable {
    
    @Override
    public void run(){
       v2 ventana2 = new v2(); 
    }
    
}
